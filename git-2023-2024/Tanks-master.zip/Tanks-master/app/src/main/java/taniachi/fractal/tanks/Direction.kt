package taniachi.fractal.tanks

// Class of directions
enum class Direction
{
    UP,
    DOWN,
    RIGHT,
    LEFT
}