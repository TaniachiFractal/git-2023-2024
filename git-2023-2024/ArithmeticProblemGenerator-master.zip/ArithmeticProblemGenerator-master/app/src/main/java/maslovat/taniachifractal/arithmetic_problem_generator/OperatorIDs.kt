package maslovat.taniachifractal.ariithmetic_problem_generator_and_verifier

import java.util.function.BinaryOperator

public const val PLUS_ID = 0
public const val MINUS_ID = 1
public const val MULTIPLY_ID = 2
public const val DIVIDE_ID = 3