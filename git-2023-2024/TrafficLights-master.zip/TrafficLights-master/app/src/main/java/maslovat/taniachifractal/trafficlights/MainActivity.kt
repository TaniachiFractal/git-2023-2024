@file:Suppress("DEPRECATION")

package maslovat.taniachifractal.trafficlights

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import maslovat.taniachifractal.trafficlights.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
   /** Link to the main layout activity_main.xml; "fld" means "field"*/
    private lateinit var fld: ActivityMainBinding
    val REDid = 0; val YELLOWid1 = 1; val GREENid = 2; val YELLOWid3 = 3;
    var currLight = REDid; val currLight_name = "currLight"

    /**Loading*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // convert xml elements to widgets kotlin can work with
        fld = ActivityMainBinding.inflate(layoutInflater)
        setContentView(fld.root)
        allLightsOff(); setLight()
        fld.btSwitch.setOnClickListener{switchLight()}
    }
    /**Save id of a traffic light*/
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(currLight_name,currLight)
    }
    /**Load saved id of a traffic light*/
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        currLight = savedInstanceState.getInt(currLight_name)
        allLightsOff(); setLight()
    }

    /**Change current traffic light*/
    private fun switchLight()
    {
        currLight++
        currLight %= 4
        allLightsOff()
        setLight()
    }
    /**Set color to the selected light*/
    private fun setLight()
    {
        when (currLight)
        {
            REDid -> fld.redLight.setBackgroundColor(resources.getColor(R.color.red))
            YELLOWid1 -> fld.yellowLight.setBackgroundColor(resources.getColor(R.color.yellow))
            GREENid -> fld.greenLight.setBackgroundColor(resources.getColor(R.color.green))
            YELLOWid3 -> fld.yellowLight.setBackgroundColor(resources.getColor(R.color.yellow))
        }
    }
    /**Turn all lights gray*/
    private fun allLightsOff()
    {
        fld.redLight.setBackgroundColor(resources.getColor(R.color.gray))
        fld.yellowLight.setBackgroundColor(resources.getColor(R.color.gray))
        fld.greenLight.setBackgroundColor(resources.getColor(R.color.gray))
    }
}