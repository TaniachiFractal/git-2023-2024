package maslovat.taniachifractal.riddles

import androidx.appcompat.app.AppCompatActivity

var crRdId = 0
var correctCount = 0
var solvedCorrectly = false

/**Methods for all activities*/
class AllActivities : AppCompatActivity()
{
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

}