﻿using System;
using System.Windows.Forms;

namespace MaslovaT_task13_practice2024
{
    public partial class HelpForm : Form
    {
        public HelpForm()
        {
            InitializeComponent();
        }

        private void BtOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
