﻿namespace МасловаПрогМодулиДЗ_1
{
    partial class Task1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Task1));
            this.lbTip = new System.Windows.Forms.Label();
            this.picPsyduck = new System.Windows.Forms.PictureBox();
            this.BTgo2 = new System.Windows.Forms.Button();
            this.lbTip2 = new System.Windows.Forms.Label();
            this.BTgo3 = new System.Windows.Forms.Button();
            this.BTgo4 = new System.Windows.Forms.Button();
            this.BTgo5 = new System.Windows.Forms.Button();
            this.BTgo6 = new System.Windows.Forms.Button();
            this.BTgo7 = new System.Windows.Forms.Button();
            this.BTgo8 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picPsyduck)).BeginInit();
            this.SuspendLayout();
            // 
            // lbTip
            // 
            this.lbTip.AutoSize = true;
            this.lbTip.Location = new System.Drawing.Point(12, 9);
            this.lbTip.Name = "lbTip";
            this.lbTip.Size = new System.Drawing.Size(157, 25);
            this.lbTip.TabIndex = 0;
            this.lbTip.Text = "Кликни по форме";
            // 
            // picPsyduck
            // 
            this.picPsyduck.Image = ((System.Drawing.Image)(resources.GetObject("picPsyduck.Image")));
            this.picPsyduck.Location = new System.Drawing.Point(17, 51);
            this.picPsyduck.Name = "picPsyduck";
            this.picPsyduck.Size = new System.Drawing.Size(136, 135);
            this.picPsyduck.TabIndex = 1;
            this.picPsyduck.TabStop = false;
            this.picPsyduck.Visible = false;
            this.picPsyduck.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picPsyduck_MouseClick);
            // 
            // BTgo2
            // 
            this.BTgo2.Location = new System.Drawing.Point(17, 241);
            this.BTgo2.Name = "BTgo2";
            this.BTgo2.Size = new System.Drawing.Size(34, 41);
            this.BTgo2.TabIndex = 2;
            this.BTgo2.Text = "2";
            this.BTgo2.UseVisualStyleBackColor = true;
            this.BTgo2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgoNext_MouseClick);
            // 
            // lbTip2
            // 
            this.lbTip2.AutoSize = true;
            this.lbTip2.Location = new System.Drawing.Point(12, 204);
            this.lbTip2.Name = "lbTip2";
            this.lbTip2.Size = new System.Drawing.Size(194, 25);
            this.lbTip2.TabIndex = 3;
            this.lbTip2.Text = "Открыть упражнение:";
            this.lbTip2.Click += new System.EventHandler(this.label1_Click);
            // 
            // BTgo3
            // 
            this.BTgo3.Location = new System.Drawing.Point(57, 241);
            this.BTgo3.Name = "BTgo3";
            this.BTgo3.Size = new System.Drawing.Size(34, 41);
            this.BTgo3.TabIndex = 4;
            this.BTgo3.Text = "3";
            this.BTgo3.UseVisualStyleBackColor = true;
            this.BTgo3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo3_MouseClick);
            // 
            // BTgo4
            // 
            this.BTgo4.Location = new System.Drawing.Point(97, 241);
            this.BTgo4.Name = "BTgo4";
            this.BTgo4.Size = new System.Drawing.Size(34, 41);
            this.BTgo4.TabIndex = 5;
            this.BTgo4.Text = "4";
            this.BTgo4.UseVisualStyleBackColor = true;
            this.BTgo4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo4_MouseClick);
            // 
            // BTgo5
            // 
            this.BTgo5.Location = new System.Drawing.Point(137, 241);
            this.BTgo5.Name = "BTgo5";
            this.BTgo5.Size = new System.Drawing.Size(34, 41);
            this.BTgo5.TabIndex = 6;
            this.BTgo5.Text = "5";
            this.BTgo5.UseVisualStyleBackColor = true;
            this.BTgo5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo5_MouseClick);
            // 
            // BTgo6
            // 
            this.BTgo6.Location = new System.Drawing.Point(177, 241);
            this.BTgo6.Name = "BTgo6";
            this.BTgo6.Size = new System.Drawing.Size(34, 41);
            this.BTgo6.TabIndex = 7;
            this.BTgo6.Text = "6";
            this.BTgo6.UseVisualStyleBackColor = true;
            this.BTgo6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo6_MouseClick);
            // 
            // BTgo7
            // 
            this.BTgo7.Location = new System.Drawing.Point(217, 241);
            this.BTgo7.Name = "BTgo7";
            this.BTgo7.Size = new System.Drawing.Size(34, 41);
            this.BTgo7.TabIndex = 8;
            this.BTgo7.Text = "7";
            this.BTgo7.UseVisualStyleBackColor = true;
            this.BTgo7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo7_MouseClick);
            // 
            // BTgo8
            // 
            this.BTgo8.Location = new System.Drawing.Point(257, 241);
            this.BTgo8.Name = "BTgo8";
            this.BTgo8.Size = new System.Drawing.Size(34, 41);
            this.BTgo8.TabIndex = 9;
            this.BTgo8.Text = "8";
            this.BTgo8.UseVisualStyleBackColor = true;
            this.BTgo8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BTgo8_MouseClick);
            // 
            // Task1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(307, 294);
            this.Controls.Add(this.BTgo8);
            this.Controls.Add(this.BTgo7);
            this.Controls.Add(this.BTgo6);
            this.Controls.Add(this.BTgo5);
            this.Controls.Add(this.BTgo4);
            this.Controls.Add(this.BTgo3);
            this.Controls.Add(this.lbTip2);
            this.Controls.Add(this.BTgo2);
            this.Controls.Add(this.picPsyduck);
            this.Controls.Add(this.lbTip);
            this.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Task1";
            this.Text = "Задание 1";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Task1_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.picPsyduck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTip;
        private System.Windows.Forms.PictureBox picPsyduck;
        private System.Windows.Forms.Button BTgo2;
        private System.Windows.Forms.Label lbTip2;
        private System.Windows.Forms.Button BTgo3;
        private System.Windows.Forms.Button BTgo4;
        private System.Windows.Forms.Button BTgo5;
        private System.Windows.Forms.Button BTgo6;
        private System.Windows.Forms.Button BTgo7;
        private System.Windows.Forms.Button BTgo8;
    }
}

