﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace GraThing_by_TaniachiFractal
{
    public partial class GraphForm : Form
    {
        #region public

        /// <summary>
        /// The amount of graphs to be drawn
        /// </summary>
        public int GraphCount;
        /// <summary>
        /// The identificator of the current coordinate system
        /// </summary>
        public byte CoordSys_Id;
        /// <summary>
        /// The minimal and maximum value of t for parametric functions
        /// </summary>
        public double tMax, tMin;

        /// <summary>
        /// Boot every render method
        /// </summary>
        public void DrawAll()
        {
            UpdateBackground();
            DrawStrips();
            switch (CoordSys_Id)
            {
                case Cnst.CARTESIAN_ID:
                    DrawCartesianGraphs(); break;
                case Cnst.POLAR_ID: 
                    DrawPolarGraphs(); break;
                case Cnst.PARAM_ID: 
                    DrawParametricGraphs(); break;
            }
        }

        /// <summary>
        /// Form constructor
        /// </summary>
        public GraphForm()
        {
            InitializeComponent();
        }

        #endregion

        #region data

        #region graphics

        /// <summary>
        /// Main drawing field
        /// </summary>
        Graphics canvas;

        /// <summary>
        /// Info on drawing various things on the form
        /// </summary>
        Pen AxisPen, StripPen;

        /// <summary>
        /// Graph pens
        /// </summary>
        Pen[] GraphPen = new Pen[10];

        /// <summary>
        /// Info on drawing various things on the form
        /// </summary>
        Brush Stripbrush;

        #endregion

        #region sizes

        /// <summary>
        /// Arrow dimens
        /// </summary>
        int arrowHeight, arrowWidth;
        /// <summary>
        /// Distance between 2 strips
        /// </summary>
        int gridSize;
        /// <summary>
        /// Length of 1 strip
        /// </summary>
        int stripSize;
        /// <summary>
        /// Font size of little integers
        /// </summary>
        int incrFntSz;
        /// <summary>
        /// Window dimens
        /// </summary>
        int winWidth, winHeight, horizMiddle, vertMiddle;

        #endregion

        #region calc

        /// <summary>
        /// What is actually between 2 strips, 0-1 or 0-10 or 0-100, etc.
        /// </summary>
        int graphIncrement;
        /// <summary>
        /// The start and the end of the graph
        /// </summary>
        int currMaxX, currMinX;

        /// <summary>
        /// Step between calculating coords
        /// </summary>
        double step;

        /// <summary>
        /// The cartesian functions that are drawn currently
        /// </summary>
        List<Func<double, double>> GraphFunction_cartesian = new List<Func<double, double>>();
        /// <summary>
        /// The polar functions that are drawn currently
        /// </summary>
        List<Func<double, double>> GraphFunction_polar = new List<Func<double, double>>();
        /// <summary>
        /// The parametric functions that are drawn currently
        /// </summary>
        List<Func<double, (double, double)>> GraphFunction_parametric = new List<Func<double, (double,double)>>();

        #endregion

        #region misc

        /// <summary>
        /// Names of axis
        /// </summary>
        string HorizAxisName, VertAxisName;

        /// <summary>
        /// Previous state of the window
        /// </summary>
        FormWindowState oldWindowState;

        #endregion

        #endregion

        #region form events

        /// <summary>
        /// Redraw strips and graph after resizing
        /// </summary>
        private void GraphForm_ResizeEnd(object sender, EventArgs e)
        {
            DrawAll();
        }

        /// <summary>
        /// Load the form
        /// </summary>
        private void GraphForm_Load(object sender, EventArgs e)
        {
            InitVars();
        }

        /// <summary>
        /// Kill app
        /// </summary>
        private void GraphForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Redraw axis
        /// </summary>
        private void GraphForm_Resize(object sender, EventArgs e)
        {
            ReInitVars();
            UpdateBackground();
            if (WindowState == FormWindowState.Maximized ||
                (WindowState == FormWindowState.Normal && oldWindowState != WindowState))
            {
                GraphForm_ResizeEnd(sender, e);
            }
            oldWindowState = WindowState;
        }

        #endregion

        #region render

        /// <summary>
        /// Redraw all the secondary elements on the form except for strips (they take too much time to update)
        /// </summary>
        private void UpdateBackground()
        {
            canvas.Clear(BackColor);

            #region coords

            Point vertAxisEnd = new Point(horizMiddle, Cnst.padding),
                  vertAxisStart = new Point(horizMiddle, winHeight - Cnst.padding * 5),
                  horizAxisEnd = new Point(winWidth - Cnst.padding * 3, vertMiddle),
                  horizAxisStart = new Point(Cnst.padding, vertMiddle),
                  center = new Point(horizMiddle, vertMiddle);

            #endregion

            #region Draw axis

            canvas.DrawLine(AxisPen, vertAxisStart, vertAxisEnd); // vertical
            canvas.DrawLine(AxisPen, horizAxisStart, horizAxisEnd); // horizontal

            #endregion

            #region Add axis arrows

            canvas.DrawLine(AxisPen, vertAxisEnd,
                new Point(horizMiddle - arrowWidth, Cnst.padding + arrowHeight)); //  ^
            canvas.DrawLine(AxisPen, vertAxisEnd,
                new Point(horizMiddle + arrowWidth, Cnst.padding + arrowHeight));

            canvas.DrawLine(AxisPen, horizAxisEnd,
                new Point(winWidth - Cnst.padding * 3 - arrowHeight, vertMiddle + arrowWidth)); // >
            canvas.DrawLine(AxisPen, horizAxisEnd,
                new Point(winWidth - Cnst.padding * 3 - arrowHeight, vertMiddle - arrowWidth));

            #endregion

            #region Add axis names

            // Horizontal
            canvas.DrawString(HorizAxisName, Font, Stripbrush, horizAxisEnd);
            // Vertical
            canvas.DrawString(" " + VertAxisName, Font, Stripbrush, vertAxisEnd);

            #endregion

            #region add increment value

            // 0
            canvas.DrawString("0", new Font(FontFamily.GenericSansSerif, incrFntSz), Stripbrush,
                new Point(horizMiddle - incrFntSz - 1, vertMiddle + 1));

            #endregion
        }

        /// <summary>
        /// Draw strips on the field
        /// </summary>
        private void DrawStrips()
        {
            #region draw strip and int methods

            // Draw 1 strip
            void DrawStrip(int distFromZero, bool vertical)
            {
                int halfStrip = stripSize / 2;
                if (vertical)
                {
                    canvas.DrawLine(StripPen, new Point(horizMiddle - halfStrip, vertMiddle + distFromZero),
                        new Point(horizMiddle + halfStrip, vertMiddle + distFromZero));
                }
                else
                {
                    canvas.DrawLine(StripPen, new Point(horizMiddle + distFromZero, vertMiddle - halfStrip),
                        new Point(horizMiddle + distFromZero, vertMiddle + halfStrip));
                }
            }

            // Draw 1 integer
            void DrawInt(int num, int distFromZero, bool vertical)
            {
                int halfStrip = stripSize / 2;
                if (vertical)
                {
                    canvas.DrawString(num.ToString(), new Font(FontFamily.GenericSansSerif, incrFntSz), Stripbrush,
                        new Point(horizMiddle - halfStrip + stripSize + halfStrip, vertMiddle + distFromZero - incrFntSz));

                }
                else
                {
                    canvas.DrawString(num.ToString(), new Font(FontFamily.GenericSansSerif, incrFntSz), Stripbrush,
                        new Point(horizMiddle + distFromZero - incrFntSz, vertMiddle - halfStrip + stripSize));

                }
            }

            // Draw both
            void DrawStripAndInt(int num, int distFromZero, bool vertical)
            {
                DrawStrip(distFromZero, vertical);
                DrawInt(num, distFromZero, vertical);
            }

            #endregion

            #region draw cycles

            //  → >
            int currDistFromZero = gridSize;
            int i = graphIncrement;
            while (currDistFromZero < horizMiddle - Cnst.padding * 4)
            {
                DrawStripAndInt(i, currDistFromZero, false); i += graphIncrement;
                currDistFromZero += gridSize;
            }
            currMaxX = i;
            //  < ←
            i = -graphIncrement;
            currDistFromZero = -gridSize;
            while (currDistFromZero > -horizMiddle + Cnst.padding * 2)
            {
                DrawStripAndInt(i, currDistFromZero, false); i -= graphIncrement;
                currDistFromZero -= gridSize;
            }
            currMinX = i;
            //  ↓ \/
            i = -graphIncrement;
            currDistFromZero = gridSize;
            while (currDistFromZero < vertMiddle -   Cnst.padding * 4)
            {
                DrawStripAndInt(i, currDistFromZero, true); i -= graphIncrement;
                currDistFromZero += gridSize;
            }
            // ↑ /\
            i = graphIncrement;
            currDistFromZero = -gridSize;
            while (currDistFromZero > -vertMiddle + Cnst.padding * 3)
            {
                DrawStripAndInt(i, currDistFromZero, true); i += graphIncrement;
                currDistFromZero -= gridSize;
            }

            #endregion
        }

        #region cartesian

        /// <summary>
        /// Draw start single line of start graph
        /// </summary>
        private void DrawCartesianGraphLine(Func<double, double> graphFunct, double startX, double endX, int graphNum)
        {
            double startY = graphFunct(startX);
            double endY = graphFunct(endX);

            Point start = DoubleToCoord(startX, startY);
            Point end = DoubleToCoord(endX, endY);

            if (start != Cnst.undefined && end != Cnst.undefined)
            {
                try { canvas.DrawLine(GraphPen[graphNum], start, end); }
                catch { } // Draw line
            }
        }

        /// <summary>
        /// Draw a cartesian graph
        /// </summary>
        private void DrawOneCartesianGraph(Func<double, double> graphFunct, int graphNum)
        {
            for (double i = currMinX * 2; i < currMaxX * 2; i += step)
            {
                DrawCartesianGraphLine(graphFunct, i, i + step, graphNum);
            }
        }

        /// <summary>
        /// Draw all cartesian graphs
        /// </summary>
        private void DrawCartesianGraphs()
        {
            for (int i = 0; i < GraphCount; i++)
            {
                DrawOneCartesianGraph(GraphFunction_cartesian[i], i);
            }
        }

        #endregion

        #region polar

        /// <summary>
        /// Draw all polar graphs
        /// </summary>
        private void DrawPolarGraphs()
        {

        }

        #endregion

        #region parametric

        /// <summary>
        /// Draw a single line of a param graph
        /// </summary>
        private void DrawParametricGraphLine(Func<double, (double,double)> graphFunct, double startT, double endT, int graphNum)
        {
            (double startX, double startY) = graphFunct(startT);
            (double endX, double endY) = graphFunct(endT);  

            Point start = DoubleToCoord(startX, startY);
            Point end = DoubleToCoord(endX, endY);

            if (start != Cnst.undefined && end != Cnst.undefined)
            {
                try { canvas.DrawLine(GraphPen[graphNum], start, end); }
                catch { } // Draw line
            }
        }

        /// <summary>
        /// Draw a parametric graph
        /// </summary>
        private void DrawOneParametricGraph(Func<double, (double, double)> graphFunct, int graphNum)
        {
            for (double i = tMin; i < tMax; i += step)
            {
                DrawParametricGraphLine(graphFunct, i, i + step, graphNum);
            }
        }

        /// <summary>
        /// Draw all parametric graphs
        /// </summary>
        private void DrawParametricGraphs()
        {
            for (int i = 0; i < GraphCount; i++)
            {
                DrawOneParametricGraph(GraphFunction_parametric[i], i);
            }
        }

        #endregion

        #endregion

        #region calculating

        /// <returns>Actual screen coords based on calculated doubles</returns>
        Point DoubleToCoord(double x, double y)
        {
            double outX, outY;

            outX = x * gridSize / graphIncrement;
            outY = -y * gridSize / graphIncrement;
            outX += horizMiddle;
            outY += vertMiddle;

            int finX = (int)outX;
            int finY = (int)outY;

            if (finX == int.MinValue || finY == int.MinValue || finX == int.MaxValue || finY == int.MaxValue)
            {
                return Cnst.undefined;
            }

            return new Point(finX, finY);
        }

        /// <summary>
        /// Distance between 2 points
        /// </summary>
        double Distance(Point point1, Point point2)
        {

            double output = Math.Sqrt(
                     (point1.X - point2.X) * (point1.X - point2.X)
                   +
                     (point1.Y - point2.Y) * (point1.Y - point2.Y)
                            );
            return output;

        }

        #endregion

        #region init

        /// <summary>
        /// recalc variables
        /// </summary>
        private void ReInitVars()
        {
            canvas = this.CreateGraphics();

            winWidth = this.Width;
            winHeight = this.Height;

            arrowHeight = winWidth / 150; if (arrowHeight < 6) arrowHeight = 6;
            arrowWidth = arrowHeight / 2;
            horizMiddle = winWidth / 2 - Cnst.padding;
            vertMiddle = winHeight / 2 - Cnst.padding;

            incrFntSz = winWidth / 40 / 3; if (incrFntSz > 8) incrFntSz = 8;
            InitCartesianGraphs();
            InitParametricGraphs();
            InitPolarGraphs();
        }

        /// <summary>
        /// Init variables
        /// </summary>
        private void InitVars()
        {
            canvas = this.CreateGraphics();

            winWidth = this.Width;
            winHeight = this.Height;

            arrowHeight = winWidth / 150; if (arrowHeight < 6) arrowHeight = 6;
            arrowWidth = arrowHeight / 2;
            horizMiddle = winWidth / 2 - Cnst.padding;
            vertMiddle = winHeight / 2 - Cnst.padding;

            incrFntSz = winWidth / 40 / 3; if (incrFntSz > 8) incrFntSz = 8;

            AxisPen = new Pen(Colors.AxisColor, 1);
            StripPen = new Pen(Colors.StripColor, 1);
            Stripbrush = new SolidBrush(Colors.StripColor);
            InitGraphPens();
            stripSize = 4;
            graphIncrement = 1;
            HorizAxisName = "x";
            VertAxisName = "y";
            gridSize = 30;
            step = 0.01;

            InitCartesianGraphs();
            InitParametricGraphs();
            InitPolarGraphs();
        }

        /// <summary>
        /// Initialize pens for all graphs
        /// </summary>
        private void InitGraphPens()
        {
            for (int i = 0; i < Cnst.MaxGraphCount; i++)
            {
                GraphPen[i] = new Pen(Colors.GraphColor[i], 2);
            }
        }

        /// <summary>
        /// Init current cartesian graphs functions
        /// </summary>
        private void InitCartesianGraphs()
        {
            GraphFunction_cartesian.Add(Xpow2);
            GraphFunction_cartesian.Add(SinX);
            GraphFunction_cartesian.Add(eq2);

            GraphFunction_cartesian.Add(Hyperbola);
            GraphFunction_cartesian.Add(HalfCircle);
            GraphFunction_cartesian.Add(eqX);

            GraphFunction_cartesian.Add(Math.Tan);
            GraphFunction_cartesian.Add(Math.Cos);
            GraphFunction_cartesian.Add(Math.Round);

            GraphFunction_cartesian.Add(Math.Abs);
        }
        /// <summary>
        /// Init current polar graphs functions
        /// </summary>
        private void InitPolarGraphs()
        {
            GraphFunction_polar.Add(Xpow2);
            GraphFunction_polar.Add(SinX);
            GraphFunction_polar.Add(eq2);

            GraphFunction_polar.Add(Hyperbola);
            GraphFunction_polar.Add(HalfCircle);
            GraphFunction_polar.Add(eqX);

            GraphFunction_polar.Add(Math.Tan);
            GraphFunction_polar.Add(Math.Cos);
            GraphFunction_polar.Add(Math.Round);

            GraphFunction_polar.Add(Math.Abs);
        }
        /// <summary>
        /// Init current parametric graphs functions
        /// </summary>
        private void InitParametricGraphs()
        {
            GraphFunction_parametric.Add(Tparam);
            GraphFunction_parametric.Add(CircleParam);
            GraphFunction_parametric.Add(Ellipse);

            GraphFunction_parametric.Add(Tparam);
            GraphFunction_parametric.Add(CircleParam);
            GraphFunction_parametric.Add(Ellipse);

            GraphFunction_parametric.Add(Tparam);
            GraphFunction_parametric.Add(CircleParam);
            GraphFunction_parametric.Add(Ellipse);

            GraphFunction_parametric.Add(Tparam);
        }

        #endregion

        #region functions to draw

        double Xpow2(double x)
        {
            return x * x;
        }

        double SinX(double x)
        {
            return 2 * Math.Sin(0.5 * x);
        }

        double eq2(double x)
        {
            return 2;
        }

        double Hyperbola(double x)
        {
            return 4 / x;
        }

        double HalfCircle(double x)
        {
            return Math.Sqrt(5 - x * x);
        }

        double eqX(double x)
        {
            return 2 * x;
        }

        (double, double) Tparam(double t)
        {
            return (t*t, t);
        }

        (double,double) CircleParam(double t)
        {
            return (Math.Sin(t), Math.Cos(t));
        }

        (double, double) Ellipse(double t)
        {
            return (Math.Sin(t), 2*Math.Cos(t));
        }

        #endregion
    }
}
