interface IDrink //interface for making you buy a coffee
{
    fun drinkSale()
}