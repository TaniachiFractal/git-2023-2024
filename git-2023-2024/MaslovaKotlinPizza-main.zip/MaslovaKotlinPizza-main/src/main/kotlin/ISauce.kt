//interface for making you buy a sauce
interface ISauce
{
    fun SauceSale()
}