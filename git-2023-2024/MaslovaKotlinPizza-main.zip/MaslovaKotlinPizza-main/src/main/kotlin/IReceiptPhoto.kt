interface IReceiptPhoto //interface for showing a receipt to get a discount
{
    fun showReceiptPhoto()
}